Downloaded from https://postgis.net/workshops/postgis-intro/index.html
